var b = require('bonescript');
var bb = require('./bb');
/*
bb.initGPIO({name:'P9_23', direction: b.INPUT, slew:'fast', pull:'pulldown'}, function(err) {
  if (err) return console.error('ERROR: ', err);
  console.log(b.getPinMode('P9_23'));
});
*/

  // console.log(b.getPinMode('P9_17'));
  // console.log(b.getPinMode('P9_18'));
  console.log(b.getPinMode('P9_21'));
  // console.log(b.getPinMode('P9_22'));
